<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['JWT_KEY'] = 'G4NT3NG';