###################
QQMS System 
###################

- Admin QQ
  - Notifikasi kalau ada berita acara butuh approval
  - Notifikasi Sample bbm h-1 dan hari H
  - Lihat , update , dan approve data berita acara
  - Rekap berita acara (export excel)
  - tambah data sample bbm untuk pemusnahan
  - konfirmasi sample bbm telah dimusnahkan ( hanya sesuai hari atau lebih)
  - Rekap Hasil pemusnahan sample bbm (export excel)
  - Manajemen data user

- Gatekeeper
  - input data berita acara
  - lihat data berita acara

- BA Pertashop
  - update kapasitas tbbm diterima berita acara